#!/usr/bin/env python3
"""
Gradle Migration Module

Handles all Gradle-related migrations including:
- Version Catalogs (libs.versions.toml)
- Dependencies in build.gradle files
- Plugin declarations and integrations
- Configuration blocks (Instabug -> instabug)

Author: Instabug SDK Team
Version: 1.0.0
"""

import os
import re
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Set

# Using regex-based TOML parsing only (no external dependencies)
TOML_AVAILABLE = False
toml = None

logger = logging.getLogger(__name__)

class GradleMigrator:
    def __init__(self, project_path: Path, dry_run: bool = False, file_logger = None):
        self.project_path = project_path
        self.dry_run = dry_run
        self.file_logger = file_logger
        self.suppress_detailed_output = bool(file_logger and hasattr(file_logger, 'output_file_path') and file_logger.output_file_path and dry_run)
        self.stats = {
            'files_processed': 0,
            'files_modified': 0,
            'replacements_made': 0,
            'errors': 0
        }
        
        # Directories to skip during migration
        self.skip_dirs = {
            '.git', '.gradle', 'build', '.idea', 
            'gradle', 'migration-backup'
        }
        
        # Version mappings
        self.luciq_version = "16.0.1"
        
        # Complete artifact name mappings from migration guide
        self.artifact_mappings = {
            'instabug': 'luciq',
            'instabug-apm': 'luciq-apm',
            'instabug-crash': 'luciq-crash',
            'instabug-bug': 'luciq-bug',
            'instabug-survey': 'luciq-survey',
            'instabug-features-request': 'luciq-features-request',
            'instabug-ndk-crash': 'luciq-ndk-crash',
            'instabug-compose': 'luciq-compose',
            'instabug-compose-apm': 'luciq-compose-apm',
            'instabug-apm-okhttp-interceptor': 'luciq-apm-okhttp-interceptor',
            'instabug-apm-grpc-interceptor': 'luciq-apm-grpc-interceptor',
            'instabug-core': 'luciq-core',
            'instabug-with-okhttp-interceptor': 'luciq-with-okhttp-interceptor',
            'instabug-plugin': 'luciq-plugin',
            'instabug-compiler-extension': 'luciq-compiler-extension',
            'instabug-test-report': 'luciq-test-report',
            'instabug-compose-core': 'luciq-compose-core'
        }
        
        # Configuration mappings
        self.config_mappings = {
            'Instabug': 'instabug',  # Legacy -> New
            'APM': 'apm',
            'debugEnabled': 'debugLogsEnabled'
        }
    
    def _filter_files_by_skip_dirs(self, files: List[Path]) -> List[Path]:
        """Filter out files that are in skip directories, with exceptions for important files"""
        filtered_files = []
        for file_path in files:
            # Check if any parent directory is in skip_dirs
            skip_file = False
            for parent in file_path.parents:
                if parent.name in self.skip_dirs:
                    # Special exception: Allow TOML files in gradle directory (version catalogs)
                    if parent.name == 'gradle' and file_path.suffix.lower() == '.toml':
                        continue  # Don't skip TOML files in gradle directory
                    skip_file = True
                    break
            if not skip_file:
                filtered_files.append(file_path)
        return filtered_files

    def migrate_all_gradle_files(self) -> bool:
        """Migrate all Gradle-related files in the project"""
        if self.file_logger:
            self.file_logger.log_step_header("Starting Gradle migration...")
        else:
            logger.info("Starting Gradle migration...")
        
        success = True
        
        # Step 1: Migrate Version Catalogs
        if not self._migrate_version_catalogs():
            success = False
            
        # Step 2: Migrate build.gradle files
        if not self._migrate_build_gradle_files():
            success = False
            
        # Step 3: Migrate plugin configurations
        if not self._migrate_plugin_configurations():
            success = False
            
        return success

    def _migrate_version_catalogs(self) -> bool:
        """Migrate libs.versions.toml files"""
        if self.file_logger:
            self.file_logger.log_step_header("Migrating version catalogs...")
        else:
            logger.info("Migrating version catalogs...")
        
        # Find all TOML files
        toml_files = list(self.project_path.rglob("*.toml"))
        toml_files = self._filter_files_by_skip_dirs(toml_files)
        
        logger.info(f"Found {len(toml_files)} TOML files: {[f.name for f in toml_files]}")
        
        # Filter for version catalog files (more inclusive approach)
        version_catalog_files = []
        for f in toml_files:
            filename_lower = f.name.lower()
            # Check for common version catalog patterns
            if any(pattern in filename_lower for pattern in ['version', 'libs', 'catalog', 'dependencies']):
                version_catalog_files.append(f)
            # Also check content for version catalog indicators
            else:
                try:
                    with open(f, 'r', encoding='utf-8') as file:
                        content = file.read()
                        if any(indicator in content for indicator in ['[versions]', '[libraries]', '[plugins]', 'com.instabug']):
                            version_catalog_files.append(f)
                            logger.info(f"Added {f.name} based on content analysis")
                except Exception:
                    pass  # Skip files that can't be read
        
        logger.info(f"Processing {len(version_catalog_files)} version catalog files: {[f.name for f in version_catalog_files]}")
        
        success = True
        for toml_file in version_catalog_files:
            if not self._migrate_version_catalog_file(toml_file):
                success = False
                
        return success


    def _migrate_toml_with_regex(self, content: str) -> tuple[str, int]:
        """Fallback regex-based TOML migration when TOML parsing is not available"""
        modified_content = content
        replacements = 0
        
        # FIRST: Track version references that are actually used by Instabug libraries
        # This must be done BEFORE we replace the group/plugin IDs
        version_refs_used_by_instabug = set()
        
        # Find libraries that use com.instabug.library group and track their version refs
        library_pattern = r'([\w-]+)\s*=\s*\{[^}]*group\s*=\s*"com\.instabug\.library"[^}]*version\.ref\s*=\s*"([^"]+)"[^}]*\}'
        for match in re.finditer(library_pattern, content):
            version_ref = match.group(2)
            version_refs_used_by_instabug.add(version_ref)
        
        # Also find libraries that use module format with com.instabug.library and track their version refs
        module_pattern = r'([\w-]+)\s*=\s*\{[^}]*module\s*=\s*"com\.instabug\.library:[^"]*"[^}]*version\.ref\s*=\s*"([^"]+)"[^}]*\}'
        for match in re.finditer(module_pattern, content):
            version_ref = match.group(2)
            version_refs_used_by_instabug.add(version_ref)
        
        # Also find plugins that use com.instabug.library id and track their version refs
        plugin_pattern = r'([\w-]+)\s*=\s*\{[^}]*id\s*=\s*"com\.instabug\.library"[^}]*version\.ref\s*=\s*"([^"]+)"[^}]*\}'
        for match in re.finditer(plugin_pattern, content):
            version_ref = match.group(2)
            version_refs_used_by_instabug.add(version_ref)
        
        # 1. Replace group references in libraries section
        pattern = r'group\s*=\s*"com\.instabug\.library"'
        new_content, count = re.subn(pattern, 'group = "ai.luciq.library"', modified_content)
        modified_content = new_content
        replacements += count
        
        # 2. Replace plugin IDs
        pattern = r'id\s*=\s*"com\.instabug\.library"'
        new_content, count = re.subn(pattern, 'id = "ai.luciq.library"', modified_content)
        modified_content = new_content
        replacements += count
        
        # 3. Replace module format dependencies (e.g., module = "com.instabug.library:instabug-apm")
        def replace_module_dependency(match):
            prefix = match.group(1)
            old_artifact = match.group(2)
            suffix = match.group(3)
            
            # Replace the group part
            new_artifact = old_artifact.replace('com.instabug.library:', 'ai.luciq.library:')
            
            # Replace the artifact name if it matches our mappings
            for old_name, new_name in self.artifact_mappings.items():
                if new_artifact.endswith(':' + old_name):
                    new_artifact = new_artifact.replace(':' + old_name, ':' + new_name)
                    break
            
            return f'{prefix}"{new_artifact}"{suffix}'
        
        module_replacement_pattern = r'(module\s*=\s*)"(com\.instabug\.library:[^"]+)"([^}]*)'
        new_content, count = re.subn(module_replacement_pattern, replace_module_dependency, modified_content)
        modified_content = new_content
        replacements += count
        
        # 4. Replace artifact names in libraries section (be more specific)
        for old_name, new_name in self.artifact_mappings.items():
            pattern = rf'name\s*=\s*"{re.escape(old_name)}"'
            new_content, count = re.subn(pattern, f'name = "{new_name}"', modified_content)
            modified_content = new_content
            replacements += count
        
        # 5. Update version references that are actually used by Instabug libraries
        # Since we've already identified these as Instabug-related through dependency tracking,
        # we should unconditionally update them to the Luciq version
        for version_ref in version_refs_used_by_instabug:
            pattern = rf'({re.escape(version_ref)})\s*=\s*"([^"]+)"'
            
            def replace_instabug_version_ref(match):
                key = match.group(1)
                old_version = match.group(2)
                # Unconditionally replace since this version ref is used by Instabug dependencies
                return f'{key} = "{self.luciq_version}"'
            
            new_content, count = re.subn(pattern, replace_instabug_version_ref, modified_content)
            modified_content = new_content
            replacements += count
        
        # 6. Handle hardcoded versions in Instabug library/plugin declarations
        # Find libraries with group format that have hardcoded versions
        hardcoded_library_pattern = r'([\w-]+\s*=\s*\{[^}]*group\s*=\s*"ai\.luciq\.library"[^}]*version\s*=\s*)"([^"]+)"([^}]*\})'
        
        def replace_hardcoded_library_version(match):
            prefix = match.group(1)
            old_version = match.group(2)
            suffix = match.group(3)
            # Replace hardcoded version with Luciq version
            return f'{prefix}"{self.luciq_version}"{suffix}'
        
        new_content, count = re.subn(hardcoded_library_pattern, replace_hardcoded_library_version, modified_content)
        modified_content = new_content
        replacements += count
        
        # Also handle hardcoded versions in module format
        hardcoded_module_pattern = r'([\w-]+\s*=\s*\{[^}]*module\s*=\s*"ai\.luciq\.library:[^"]*"[^}]*version\s*=\s*)"([^"]+)"([^}]*\})'
        
        def replace_hardcoded_module_version(match):
            prefix = match.group(1)
            old_version = match.group(2)
            suffix = match.group(3)
            # Replace hardcoded version with Luciq version
            return f'{prefix}"{self.luciq_version}"{suffix}'
        
        new_content, count = re.subn(hardcoded_module_pattern, replace_hardcoded_module_version, modified_content)
        modified_content = new_content
        replacements += count
        
        # Also handle plugins with hardcoded versions (though less common)
        hardcoded_plugin_pattern = r'([\w-]+\s*=\s*\{[^}]*id\s*=\s*"ai\.luciq\.library"[^}]*version\s*=\s*)"([^"]+)"([^}]*\})'
        
        def replace_hardcoded_plugin_version(match):
            prefix = match.group(1)
            old_version = match.group(2)
            suffix = match.group(3)
            # Replace hardcoded version with Luciq version
            return f'{prefix}"{self.luciq_version}"{suffix}'
        
        new_content, count = re.subn(hardcoded_plugin_pattern, replace_hardcoded_plugin_version, modified_content)
        modified_content = new_content
        replacements += count
        
        return modified_content, replacements

    def _migrate_version_catalog_file(self, toml_file: Path) -> bool:
        """Migrate a single version catalog file"""
        try:
            self.stats['files_processed'] += 1
            
            with open(toml_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            if 'com.instabug' not in content:
                logger.info(f"Skipping {toml_file.name} - no Instabug references found")
                return True
            
            logger.info(f"Processing {toml_file.name} - Instabug references detected")
                
            original_content = content
            modified_content = content
            replacements = 0
            
            # Use regex-based approach for TOML migration (no external dependencies)
            modified_content, regex_replacements = self._migrate_toml_with_regex(content)
            replacements += regex_replacements
            
            if replacements > 0:
                if self.dry_run:
                    if self.file_logger:
                        self.file_logger.log(f"WOULD MODIFY: {toml_file} ({replacements} replacements)", to_console=not self.suppress_detailed_output)
                    else:
                        logger.info(f"WOULD MODIFY: {toml_file} ({replacements} replacements)")
                    self._show_toml_changes(toml_file, original_content, modified_content)
                else:
                    with open(toml_file, 'w', encoding='utf-8') as f:
                        f.write(modified_content)
                    logger.info(f"Modified {toml_file} ({replacements} replacements)")
                
                self.stats['files_modified'] += 1
                self.stats['replacements_made'] += replacements
            
            return True
            
        except Exception as e:
            logger.error(f"Error migrating version catalog {toml_file}: {e}")
            self.stats['errors'] += 1
            return False


    def _migrate_build_gradle_files(self) -> bool:
        """Migrate all build.gradle and build.gradle.kts files"""
        if self.file_logger:
            self.file_logger.log_step_header("Migrating build.gradle files...")
        else:
            logger.info("Migrating build.gradle files...")
        
        gradle_files = list(self.project_path.rglob("build.gradle*"))
        gradle_files = self._filter_files_by_skip_dirs(gradle_files)
        
        success = True
        for gradle_file in gradle_files:
            if not self._migrate_build_gradle_file(gradle_file):
                success = False
                
        return success

    def _migrate_build_gradle_file(self, gradle_file: Path) -> bool:
        """Migrate a single build.gradle file"""
        try:
            self.stats['files_processed'] += 1
            
            with open(gradle_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            if 'com.instabug' not in content and 'instabug' not in content:
                return True
                
            original_content = content
            modified_content = content
            replacements = 0
            
            # Migrate dependencies
            modified_content, deps_replacements = self._migrate_dependencies(modified_content)
            replacements += deps_replacements
            
            # Migrate plugin declarations
            modified_content, plugin_replacements = self._migrate_plugin_declarations(modified_content)
            replacements += plugin_replacements
            
            # Migrate buildScript dependencies
            modified_content, buildscript_replacements = self._migrate_buildscript_dependencies(modified_content)
            replacements += buildscript_replacements
            
            if replacements > 0:
                if self.dry_run:
                    if self.file_logger:
                        self.file_logger.log(f"WOULD MODIFY: {gradle_file} ({replacements} replacements)", to_console=not self.suppress_detailed_output)
                    else:
                        logger.info(f"WOULD MODIFY: {gradle_file} ({replacements} replacements)")
                    self._show_gradle_changes(gradle_file, original_content, modified_content)
                else:
                    with open(gradle_file, 'w', encoding='utf-8') as f:
                        f.write(modified_content)
                    logger.info(f"Modified {gradle_file} ({replacements} replacements)")
                
                self.stats['files_modified'] += 1
                self.stats['replacements_made'] += replacements
            
            return True
            
        except Exception as e:
            logger.error(f"Error migrating build.gradle file {gradle_file}: {e}")
            self.stats['errors'] += 1
            return False

    def _migrate_dependencies(self, content: str) -> Tuple[str, int]:
        """Migrate dependency declarations with smart variable tracking"""
        modified_content = content
        replacements = 0
        
        # FIRST: Track version variables that are actually used by Instabug dependencies
        # This must be done BEFORE we replace the group/artifact names
        variables_used_by_instabug = set()
        
        # Find dependencies that use com.instabug.library and track their version variables
        for old_name, new_name in self.artifact_mappings.items():
            # Track variables in "com.instabug.library:artifact:$variable" format
            variable_usage_pattern = rf'["\']com\.instabug\.library:{re.escape(old_name)}:\$([a-zA-Z_][a-zA-Z0-9_]*)["\']'
            for match in re.finditer(variable_usage_pattern, content):
                var_name = match.group(1)
                variables_used_by_instabug.add(var_name)
            
            # Track variables in group/name format with version: $variable
            group_name_variable_pattern = rf'group\s*:\s*["\']com\.instabug\.library["\']\s*,\s*name\s*:\s*["\']({re.escape(old_name)})["\']\s*,\s*version\s*:\s*\$([a-zA-Z_][a-zA-Z0-9_]*)'
            for match in re.finditer(group_name_variable_pattern, content):
                var_name = match.group(2)
                variables_used_by_instabug.add(var_name)
        
        # Also check for generic com.instabug.library dependencies with variables
        generic_instabug_pattern = r'["\']com\.instabug\.library:[^:]+:\$([a-zA-Z_][a-zA-Z0-9_]*)["\']'
        for match in re.finditer(generic_instabug_pattern, content):
            var_name = match.group(1)
            variables_used_by_instabug.add(var_name)
        
        # Now perform the migrations
        
        # 1. Migrate group references
        new_content, count = re.subn(
            r'group\s*:\s*["\']com\.instabug\.library["\']',
            'group: "ai.luciq.library"',
            modified_content
        )
        modified_content = new_content
        replacements += count
        
        # 2. Migrate name references using artifact mappings
        for old_name, new_name in self.artifact_mappings.items():
            # Handle name: "artifact" format
            new_content, count = re.subn(
                rf'name\s*:\s*["\']({re.escape(old_name)})["\']',
                f'name: "{new_name}"',
                modified_content
            )
            modified_content = new_content
            replacements += count
            
            # Handle "com.instabug.library:artifact:version" format (preserve variables)
            def replace_dependency_preserve_variables(match):
                quote = match.group(1)
                version_part = match.group(3)
                # If it's a variable reference (starts with $), preserve it
                if version_part.startswith('$'):
                    return f'{quote}ai.luciq.library:{new_name}:{version_part}{quote}'
                else:
                    # If it's a hardcoded version, update it
                    return f'{quote}ai.luciq.library:{new_name}:{self.luciq_version}{quote}'
            
            new_content, count = re.subn(
                rf'(["\'])com\.instabug\.library:({re.escape(old_name)}):([^"\']+)\1',
                replace_dependency_preserve_variables,
                modified_content
            )
            modified_content = new_content
            replacements += count
        
        # 3. Update version variable declarations that are actually used by Instabug dependencies
        # Only update variables that we tracked as being used by Instabug dependencies
        for var_name in variables_used_by_instabug:
            # Handle different variable declaration formats
            var_patterns = [
                rf'(def\s+{re.escape(var_name)}\s*=\s*["\'])([^"\']+)(["\'])',
                rf'({re.escape(var_name)}\s*=\s*["\'])([^"\']+)(["\'])',
                rf'(val\s+{re.escape(var_name)}\s*=\s*["\'])([^"\']+)(["\'])'
            ]
            
            for pattern in var_patterns:
                def replace_tracked_variable(match):
                    prefix = match.group(1)
                    old_version = match.group(2)
                    suffix = match.group(3)
                    return f'{prefix}{self.luciq_version}{suffix}'
                
                new_content, count = re.subn(pattern, replace_tracked_variable, modified_content)
                modified_content = new_content
                replacements += count
        
        # 4. Update direct version references to Luciq version (only hardcoded versions, not variables)
        # Match any hardcoded version in ai.luciq.library dependencies and update to current version
        version_pattern = rf'(["\']ai\.luciq\.library:[^:]*:)([^"\'$]+)(["\'])'
        new_content, count = re.subn(
            version_pattern,
            rf'\g<1>{self.luciq_version}\g<3>',
            modified_content
        )
        modified_content = new_content
        replacements += count
        
        return modified_content, replacements

    def _migrate_plugin_declarations(self, content: str) -> Tuple[str, int]:
        """Migrate plugin declarations in plugins block"""
        modified_content = content
        replacements = 0
        
        # Plugin ID patterns for com.instabug.library with version handling
        # Handle id("com.instabug.library") version "version" format
        plugin_with_version_pattern = r'id\s*\(\s*["\']com\.instabug\.library["\']\s*\)\s+version\s+["\']([^"\']+)["\']'
        def replace_plugin_with_version(match):
            old_version = match.group(1)
            return f'id("ai.luciq.library") version "{self.luciq_version}"'
        
        new_content, count = re.subn(plugin_with_version_pattern, replace_plugin_with_version, modified_content)
        modified_content = new_content
        replacements += count
        
        # Handle id "com.instabug.library" version "version" format
        plugin_with_version_pattern_quotes = r'id\s+["\']com\.instabug\.library["\']\s+version\s+["\']([^"\']+)["\']'
        def replace_plugin_with_version_quotes(match):
            old_version = match.group(1)
            return f'id "ai.luciq.library" version "{self.luciq_version}"'
        
        new_content, count = re.subn(plugin_with_version_pattern_quotes, replace_plugin_with_version_quotes, modified_content)
        modified_content = new_content
        replacements += count
        
        # Fallback patterns for plugin IDs without explicit version (for backward compatibility)
        patterns = [
            # id "com.instabug.library" (without version)
            (r'id\s+["\']com\.instabug\.library["\'](?!\s+version)',
             'id "ai.luciq.library"'),
            
            # id("com.instabug.library") (without version)
            (r'id\s*\(\s*["\']com\.instabug\.library["\']\s*\)(?!\s+version)',
             'id("ai.luciq.library")'),
        ]
        
        for pattern, replacement in patterns:
            new_content, count = re.subn(pattern, replacement, modified_content)
            modified_content = new_content
            replacements += count
        
        # Handle apply plugin patterns using artifact mappings
        for old_name, new_name in self.artifact_mappings.items():
            # apply plugin: "instabug-xxx"
            new_content, count = re.subn(
                rf'apply\s+plugin\s*:\s*["\']({re.escape(old_name)})["\']',
                f'apply plugin: "{new_name}"',
                modified_content
            )
            modified_content = new_content
            replacements += count
            
            # id("instabug-xxx") version "version" - with version
            plugin_artifact_with_version_pattern = rf'id\s*\(\s*["\']({re.escape(old_name)})["\']\s*\)\s+version\s+["\']([^"\']+)["\']'
            def replace_artifact_plugin_with_version(match):
                old_version = match.group(2)
                return f'id("{new_name}") version "{self.luciq_version}"'
            
            new_content, count = re.subn(plugin_artifact_with_version_pattern, replace_artifact_plugin_with_version, modified_content)
            modified_content = new_content
            replacements += count
            
            # id "instabug-xxx" version "version" - with version
            plugin_artifact_with_version_pattern_quotes = rf'id\s+["\']({re.escape(old_name)})["\']\s+version\s+["\']([^"\']+)["\']'
            def replace_artifact_plugin_with_version_quotes(match):
                old_version = match.group(2)
                return f'id "{new_name}" version "{self.luciq_version}"'
            
            new_content, count = re.subn(plugin_artifact_with_version_pattern_quotes, replace_artifact_plugin_with_version_quotes, modified_content)
            modified_content = new_content
            replacements += count
            
            # id("instabug-xxx") - parentheses with quotes (without version)
            new_content, count = re.subn(
                rf'id\s*\(\s*["\']({re.escape(old_name)})["\']\s*\)(?!\s+version)',
                f'id("{new_name}")',
                modified_content
            )
            modified_content = new_content
            replacements += count
            
            # id "instabug-xxx" - quotes without parentheses (without version)
            new_content, count = re.subn(
                rf'id\s+["\']({re.escape(old_name)})["\'](?!\s+version)',
                f'id "{new_name}"',
                modified_content
            )
            modified_content = new_content
            replacements += count
            
            # id instabug-xxx - no quotes (less common but possible)
            new_content, count = re.subn(
                rf'id\s+({re.escape(old_name)})(?=\s|$)',
                f'id {new_name}',
                modified_content
            )
            modified_content = new_content
            replacements += count
        
        return modified_content, replacements

    def _migrate_buildscript_dependencies(self, content: str) -> Tuple[str, int]:
        """Migrate buildScript dependencies"""
        modified_content = content
        replacements = 0
        
        # Handle buildscript classpath dependencies using artifact mappings
        for old_name, new_name in self.artifact_mappings.items():
            # classpath "com.instabug.library:artifact:version"
            pattern = rf'classpath\s+["\']com\.instabug\.library:({re.escape(old_name)}):([^"\']+)["\']'
            
            def replace_classpath(match):
                old_version = match.group(2)
                # Unconditionally update to Luciq version since this is an Instabug dependency
                return f'classpath "ai.luciq.library:{new_name}:{self.luciq_version}"'
            
            new_content, count = re.subn(pattern, replace_classpath, modified_content)
        modified_content = new_content
        replacements += count
        
        return modified_content, replacements

    def _migrate_plugin_configurations(self) -> bool:
        """Migrate plugin configuration blocks"""
        if self.file_logger:
            self.file_logger.log_step_header("Migrating plugin configurations...")
        else:
            logger.info("Migrating plugin configurations...")
        
        gradle_files = list(self.project_path.rglob("build.gradle*"))
        gradle_files = self._filter_files_by_skip_dirs(gradle_files)
        
        success = True
        for gradle_file in gradle_files:
            if not self._migrate_plugin_config_file(gradle_file):
                success = False
                
        return success

    def _migrate_plugin_config_file(self, gradle_file: Path) -> bool:
        """Migrate plugin configurations in a single file"""
        try:
            with open(gradle_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            if 'Instabug' not in content and 'instabug' not in content:
                return True
                
            original_content = content
            modified_content = content
            replacements = 0
            
            # Parse and migrate configuration blocks
            modified_content, config_replacements = self._migrate_configuration_blocks(modified_content)
            replacements += config_replacements
            
            if replacements > 0:
                if self.dry_run:
                    if self.file_logger:
                        self.file_logger.log(f"WOULD MODIFY CONFIG: {gradle_file} ({replacements} replacements)", to_console=not self.suppress_detailed_output)
                    else:
                        logger.info(f"WOULD MODIFY CONFIG: {gradle_file} ({replacements} replacements)")
                    self._show_config_changes(gradle_file, original_content, modified_content)
                else:
                    with open(gradle_file, 'w', encoding='utf-8') as f:
                        f.write(modified_content)
                    logger.info(f"Modified config in {gradle_file} ({replacements} replacements)")
                
                self.stats['files_modified'] += 1
                self.stats['replacements_made'] += replacements
            
            return True
            
        except Exception as e:
            logger.error(f"Error migrating plugin config in {gradle_file}: {e}")
            self.stats['errors'] += 1
            return False

    def _migrate_configuration_blocks(self, content: str) -> Tuple[str, int]:
        """Migrate Instabug configuration blocks following the 12-step detailed approach"""
        modified_content = content
        replacements = 0
        
        # Find Instabug configuration blocks (legacy)
        instabug_pattern = r'Instabug\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}'
        instabug_matches = list(re.finditer(instabug_pattern, content, re.DOTALL))
        
        # Find existing instabug configuration blocks (new)
        lowercase_pattern = r'instabug\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}'
        lowercase_matches = list(re.finditer(lowercase_pattern, content, re.DOTALL))
        
        # Step 1: If neither block is defined, do nothing
        if not instabug_matches and not lowercase_matches:
            return modified_content, replacements
        
        # Parse existing blocks
        legacy_configs = {}
        new_configs = {}
        
        if instabug_matches:
            for match in instabug_matches:
                legacy_block_content = match.group(1)
                legacy_configs.update(self._parse_configuration_block_detailed(legacy_block_content))
        
        if lowercase_matches:
            for match in lowercase_matches:
                new_block_content = match.group(1)
                new_configs.update(self._parse_configuration_block_detailed(new_block_content))
        
        # Apply the 12-step migration process
        final_configs = self._apply_configuration_migration_rules(legacy_configs, new_configs)
        
        # Replace existing blocks in-place to preserve file structure
        all_matches = instabug_matches + lowercase_matches
        if all_matches and final_configs:
            # Sort matches by position (reversed for safe replacement)
            all_matches.sort(key=lambda m: m.start(), reverse=True)
            
            # Replace the first (last in reversed order) block with the new luciq block
            first_match = all_matches[-1]  # Get the first match (original position)
            new_block_content = self._generate_configuration_block_detailed(final_configs)
            new_block = f'luciq {{\n{new_block_content}\n}}'
            
            # Replace the first block with the new luciq block
            modified_content = (modified_content[:first_match.start()] + 
                              new_block + 
                              modified_content[first_match.end():])
            replacements += 1
            
            # Remove any additional blocks (if there were multiple)
            if len(all_matches) > 1:
                # Re-find matches in the modified content and remove extras
                for match in all_matches[:-1]:  # Skip the first one we already replaced
                    # Adjust positions after previous replacements
                    remaining_pattern = r'(Instabug|instabug)\s*\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}'
                    remaining_matches = list(re.finditer(remaining_pattern, modified_content, re.DOTALL))
                    if remaining_matches:
                        # Remove the first remaining block
                        match_to_remove = remaining_matches[0]
                        modified_content = (modified_content[:match_to_remove.start()] + 
                                          modified_content[match_to_remove.end():])
                        replacements += 1
        
        return modified_content, replacements

    def _parse_configuration_block_detailed(self, block_content: str) -> Dict[str, any]:
        """Parse configuration block content preserving original formatting"""
        configs = {}
        
        # Parse nested blocks (like APM/apm)
        nested_pattern = r'(\w+)\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}'
        for match in re.finditer(nested_pattern, block_content, re.DOTALL):
            block_name, nested_content = match.groups()
            configs[block_name.strip()] = self._parse_configuration_block_detailed(nested_content)
        
        # Remove nested blocks from content to avoid double parsing
        content_without_nested = re.sub(nested_pattern, '', block_content, flags=re.DOTALL)
        
        # Parse all configurations and preserve their original format
        # This captures various formats: key = value, key(value), key "value", etc.
        all_config_pattern = r'^\s*(\w+)(?:\s*\(\s*([^)]+)\s*\)|\s*=\s*([^\n,}]+)|\s+([^\s\n,}=][^\n,}]*))(?:\s*,)?\s*$'
        
        for match in re.finditer(all_config_pattern, content_without_nested, re.MULTILINE):
            key = match.group(1).strip()
            func_value = match.group(2)  # value from function call with parentheses
            assign_value = match.group(3)  # value from assignment
            space_value = match.group(4)  # value from space-separated format
            
            if func_value is not None:
                # Function call format: key(value)
                configs[key] = {
                    'type': 'function_call_parens', 
                    'value': func_value.strip(),
                    'original_format': 'function_call_parens'
                }
            elif assign_value is not None:
                # Assignment format: key = value
                configs[key] = {
                    'type': 'assignment', 
                    'value': assign_value.strip().rstrip(','),
                    'original_format': 'assignment'
                }
            elif space_value is not None:
                # Space-separated format: key value
                configs[key] = {
                    'type': 'function_call_space', 
                    'value': space_value.strip().rstrip(','),
                    'original_format': 'function_call_space'
                }
        
        return configs

    def _apply_configuration_migration_rules(self, legacy_configs: Dict, new_configs: Dict) -> Dict:
        """Apply the 12-step migration rules from the guide (steps 1-11, step 12 is handled in block generation)"""
        final_configs = {}
        
        # Step 2: If Instabug block exists but instabug doesn't, create instabug block
        # Step 3: If instabug block exists with apm, remove Instabug block
        # Step 4: If instabug exists without apm but Instabug has APM, copy APM to instabug
        
        # Start with new configs as base (they take precedence in conflicts)
        final_configs.update(new_configs)
        
        # Process legacy configs
        for key, value in legacy_configs.items():
            # Step 5: Rename APM to apm
            if key == 'APM':
                key = 'apm'
            
            # If new configs don't have this key, add it from legacy
            if key not in final_configs:
                final_configs[key] = value
            # If both have the key, merge nested blocks
            elif isinstance(value, dict) and isinstance(final_configs[key], dict):
                final_configs[key] = self._merge_nested_configs(final_configs[key], value)
        
        # Apply specific transformation rules (Steps 6-11)
        final_configs = self._apply_transformation_rules(final_configs)
        
        return final_configs

    def _merge_nested_configs(self, new_config: Dict, legacy_config: Dict) -> Dict:
        """Merge nested configuration blocks, with new config taking precedence"""
        merged = {}
        
        # Add all legacy configs first
        for key, value in legacy_config.items():
            merged[key] = value
        
        # Override with new configs (new takes precedence)
        for key, value in new_config.items():
            merged[key] = value
        
        return merged

    def _apply_transformation_rules(self, configs: Dict) -> Dict:
        """Apply ONLY the specific transformation rules (steps 6-11), preserve everything else as-is"""
        transformed = {}
        debug_logs_enabled = None
        
        # Process each top-level configuration
        for key, value in configs.items():
            if key == 'apm' and isinstance(value, dict):
                # Process APM block transformations - ONLY apply specific transformations
                apm_config = {}
                apm_debug_enabled = None
                
                for apm_key, apm_value in value.items():
                    # Step 6: debugEnabled({value}) -> remove (will be moved to top level)
                    if apm_key == 'debugEnabled':
                        apm_debug_enabled = self._extract_clean_value(apm_value)
                        # Don't add debugEnabled to apm_config - it gets removed
                    
                    # Step 7: networkInterceptingEnabled({value}) -> networkEnabled = {value}
                    elif apm_key == 'networkInterceptingEnabled':
                        clean_value = self._extract_clean_value(apm_value)
                        apm_config['networkEnabled'] = {
                            'type': 'assignment',
                            'value': clean_value,
                            'original_format': 'assignment'
                        }
                    
                    # Step 8: fragmentSpansEnabled({value}) -> fragmentSpansEnabled = {value}
                    elif apm_key == 'fragmentSpansEnabled':
                        clean_value = self._extract_clean_value(apm_value)
                        # Convert function call format to assignment format
                        if isinstance(apm_value, dict) and apm_value.get('original_format') == 'function_call_parens':
                            apm_config['fragmentSpansEnabled'] = {
                                'type': 'assignment',
                                'value': clean_value,
                                'original_format': 'assignment'
                            }
                        else:
                            # Keep original format if it wasn't a function call
                            apm_config['fragmentSpansEnabled'] = apm_value
                    
                    else:
                        # Keep ALL other configurations exactly as-is with original formatting
                        apm_config[apm_key] = apm_value
                
                # Handle debugEnabled migration (Steps 9-11)
                if apm_debug_enabled is not None:
                    # Check if setDebugLogsEnabled exists at top level
                    set_debug_logs = configs.get('setDebugLogsEnabled')
                    if set_debug_logs is not None:
                        set_debug_logs_value = self._extract_clean_value(set_debug_logs)
                        
                        # Step 9: Both true -> remove apm's debugEnabled
                        if str(apm_debug_enabled).lower() == 'true' and str(set_debug_logs_value).lower() == 'true':
                            debug_logs_enabled = 'true'
                        # Step 10: apm true, top false -> set top to true, remove apm's
                        elif str(apm_debug_enabled).lower() == 'true' and str(set_debug_logs_value).lower() == 'false':
                            debug_logs_enabled = 'true'
                        # Step 11: apm false -> remove apm's debugEnabled
                        elif str(apm_debug_enabled).lower() == 'false':
                            debug_logs_enabled = set_debug_logs_value
                        else:
                            debug_logs_enabled = set_debug_logs_value
                    else:
                        # No top-level setDebugLogsEnabled, use apm's value
                        if str(apm_debug_enabled).lower() != 'false':
                            debug_logs_enabled = apm_debug_enabled
                
                if apm_config:
                    transformed['apm'] = apm_config
            
            # Handle setDebugLogsEnabled at top level
            elif key == 'setDebugLogsEnabled':
                if debug_logs_enabled is None:
                    debug_logs_enabled = self._extract_clean_value(value)
            
            # Handle debugEnabled -> setDebugLogsEnabled transformation (Step 6)
            elif key == 'debugEnabled':
                if debug_logs_enabled is None:
                    debug_logs_enabled = self._extract_clean_value(value)
                # Don't add debugEnabled to transformed - it becomes setDebugLogsEnabled
            
            else:
                # Keep ALL other top-level configurations exactly as-is with original formatting
                transformed[key] = value
        
        # Add setDebugLogsEnabled if we determined a value (always as function call)
        if debug_logs_enabled is not None:
            transformed['setDebugLogsEnabled'] = {
                'type': 'function_call_parens',
                'value': debug_logs_enabled,
                'original_format': 'function_call_parens'
            }
        
        return transformed

    def _generate_configuration_block_detailed(self, configs: Dict) -> str:
        """Generate configuration block content preserving original formatting"""
        lines = []
        
        for key, value in configs.items():
            if isinstance(value, dict) and not self._has_original_format(value):
                # Handle nested blocks
                nested_lines = []
                for nested_key, nested_value in value.items():
                    nested_lines.append(self._format_config_line(nested_key, nested_value, '        '))
                
                if nested_lines:
                    lines.append(f'    {key} {{')
                    lines.extend(nested_lines)
                    lines.append('    }')
            else:
                # Handle simple key-value pairs
                formatted_line = self._format_config_line(key, value, '    ')
                if key == 'setDebugLogsEnabled':
                    lines.insert(0, formatted_line)  # setDebugLogsEnabled always at top
                else:
                    lines.append(formatted_line)
        
        return '\n'.join(lines)

    def _has_original_format(self, value) -> bool:
        """Check if a value has original formatting information"""
        return isinstance(value, dict) and 'original_format' in value

    def _format_config_line(self, key: str, value, indent: str) -> str:
        """Format a configuration line preserving original format"""
        clean_value = self._extract_clean_value(value)
        
        if isinstance(value, dict) and 'original_format' in value:
            original_format = value['original_format']
            
            if original_format == 'function_call_parens':
                return f'{indent}{key}({clean_value})'
            elif original_format == 'function_call_space':
                return f'{indent}{key} {clean_value}'
            elif original_format == 'assignment':
                return f'{indent}{key} = {clean_value}'
        
        # Fallback to assignment format if no original format info
        return f'{indent}{key} = {clean_value}'

    def _is_function_call_key(self, key: str, value) -> bool:
        """Determine if a key should be formatted as a function call"""
        # Check if the original value was explicitly parsed as a function call
        if isinstance(value, dict) and value.get('type') == 'function_call':
            return True
        
        # Special handling for setDebugLogsEnabled (always function call)
        if key == 'setDebugLogsEnabled':
            return True
        
        # Methods starting with 'set' and having uppercase after 'set' are function calls
        if key.startswith('set') and len(key) > 3 and key[3].isupper():
            return True
        
        # Methods ending with 'Url' are typically function calls (like uploadUrl)
        if key.endswith('Url'):
            return True
        
        return False

    def _extract_clean_value(self, value):
        """Extract clean value from potentially complex value structure"""
        if isinstance(value, dict):
            if 'value' in value:
                return value['value']
            elif 'type' in value and value['type'] in ['function_call_parens', 'function_call_space', 'assignment']:
                return value.get('value', value)
            else:
                return value
        else:
            return value

    def _parse_configuration_block(self, block_content: str) -> Dict[str, any]:
        """Parse configuration block content into a dictionary"""
        configs = {}
        
        # Parse simple key-value pairs
        kv_pattern = r'(\w+)\s*=\s*([^\n]+)'
        for match in re.finditer(kv_pattern, block_content):
            key, value = match.groups()
            configs[key.strip()] = value.strip()
        
        # Parse nested blocks (like APM)
        nested_pattern = r'(\w+)\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}'
        for match in re.finditer(nested_pattern, block_content, re.DOTALL):
            block_name, nested_content = match.groups()
            configs[block_name.strip()] = self._parse_configuration_block(nested_content)
        
        return configs

    def _generate_configuration_block(self, configs: Dict[str, any]) -> str:
        """Generate configuration block content from dictionary"""
        lines = []
        
        # Handle special mappings
        debug_enabled = False
        
        for key, value in configs.items():
            if key == 'APM' and isinstance(value, dict):
                # Handle APM block migration
                apm_lines = []
                for apm_key, apm_value in value.items():
                    if apm_key == 'debugEnabled':
                        debug_enabled = apm_value
                    else:
                        apm_lines.append(f'        {apm_key} = {apm_value}')
                
                if apm_lines:
                    lines.append('    apm {')
                    lines.extend(apm_lines)
                    lines.append('    }')
            elif key == 'debugEnabled':
                debug_enabled = value
            elif isinstance(value, dict):
                # Handle other nested blocks
                nested_lines = []
                for nested_key, nested_value in value.items():
                    nested_lines.append(f'        {nested_key} = {nested_value}')
                
                if nested_lines:
                    lines.append(f'    {key.lower()} {{')
                    lines.extend(nested_lines)
                    lines.append('    }')
            else:
                lines.append(f'    {key} = {value}')
        
        # Add debugLogsEnabled if we found debugEnabled in APM
        if debug_enabled:
            lines.insert(0, f'    debugLogsEnabled = {debug_enabled}')
        
        return '\n'.join(lines)


    def _show_toml_changes(self, file_path: Path, original: str, modified: str):
        """Show TOML file changes in dry-run mode"""
        self._show_file_changes(file_path, original, modified, "TOML")

    def _show_gradle_changes(self, file_path: Path, original: str, modified: str):
        """Show Gradle file changes in dry-run mode"""
        self._show_file_changes(file_path, original, modified, "Gradle")

    def _show_config_changes(self, file_path: Path, original: str, modified: str):
        """Show configuration changes in dry-run mode with semantic analysis"""
        self._show_semantic_config_changes(file_path, original, modified)

    def _show_semantic_config_changes(self, file_path: Path, original: str, modified: str):
        """Show only meaningful configuration changes, not formatting differences"""
        changes = []
        
        # Extract configuration blocks from both versions
        original_blocks = self._extract_config_blocks(original)
        modified_blocks = self._extract_config_blocks(modified)
        
        # Compare block names
        orig_block_names = set(original_blocks.keys())
        mod_block_names = set(modified_blocks.keys())
        
        # Block name changes (e.g., instabug -> luciq)
        if orig_block_names != mod_block_names:
            removed = orig_block_names - mod_block_names
            added = mod_block_names - orig_block_names
            
            # Track which blocks have been matched
            matched_old = set()
            matched_new = set()
            
            for old_name in removed:
                for new_name in added:
                    if new_name not in matched_new and self._are_equivalent_blocks(original_blocks[old_name], modified_blocks[new_name]):
                        changes.append(f"Configuration block renamed: {old_name} → {new_name}")
                        matched_old.add(old_name)
                        matched_new.add(new_name)
                        break
            
            # Report any unmatched removals or additions
            unmatched_removed = removed - matched_old
            unmatched_added = added - matched_new
            
            for block_name in unmatched_removed:
                changes.append(f"Configuration block removed: {block_name}")
            
            for block_name in unmatched_added:
                changes.append(f"Configuration block added: {block_name}")
        
        # Look for content changes within blocks
        for block_name in mod_block_names:
            if block_name in original_blocks:
                block_changes = self._compare_block_contents(
                    original_blocks[block_name], 
                    modified_blocks[block_name]
                )
                changes.extend([f"  {change}" for change in block_changes])
        
        # Display the meaningful changes
        if changes:
            for change in changes:
                if self.file_logger:
                    self.file_logger.log(f"  {change}", to_console=not self.suppress_detailed_output)
                else:
                    logger.info(f"  {change}")
        else:
            # If no semantic changes detected, show a summary message
            if self.file_logger:
                self.file_logger.log("  Configuration block updated (properties may have been reordered)", to_console=not self.suppress_detailed_output)
            else:
                logger.info("  Configuration block updated (properties may have been reordered)")

    def _extract_config_blocks(self, content: str) -> Dict[str, str]:
        """Extract configuration blocks and their content"""
        blocks = {}
        
        # Find all configuration blocks
        patterns = [
            r'(Instabug)\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}',
            r'(instabug)\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}',
            r'(luciq)\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}'
        ]
        
        for pattern in patterns:
            for match in re.finditer(pattern, content, re.DOTALL):
                block_name, block_content = match.groups()
                blocks[block_name] = block_content.strip()
        
        return blocks

    def _are_equivalent_blocks(self, content1: str, content2: str) -> bool:
        """Check if two configuration blocks are semantically equivalent"""
        # Normalize whitespace and compare essential content
        norm1 = re.sub(r'\s+', ' ', content1.strip())
        norm2 = re.sub(r'\s+', ' ', content2.strip())
        
        # Allow for some differences in property ordering and formatting
        # This is a simplified check - could be made more sophisticated
        return len(norm1) > 0 and len(norm2) > 0 and abs(len(norm1) - len(norm2)) < len(norm1) * 0.3

    def _compare_block_contents(self, original: str, modified: str) -> List[str]:
        """Compare configuration block contents and return meaningful changes"""
        changes = []
        
        # This is a simplified implementation - could be enhanced to detect
        # specific property changes, additions, removals, etc.
        if original.strip() != modified.strip():
            # For now, just indicate that content was modified
            changes.append("Configuration properties updated")
        
        return changes

    def _show_file_changes(self, file_path: Path, original: str, modified: str, file_type: str):
        """Show file changes in dry-run mode"""
        original_lines = original.splitlines()
        modified_lines = modified.splitlines()
        
        for i, (orig_line, mod_line) in enumerate(zip(original_lines, modified_lines)):
            if orig_line != mod_line:
                if self.file_logger:
                    # Log to file and suppress console output when output file is specified
                    self.file_logger.log(f"  Line {i+1}: {orig_line.strip()}", to_console=not self.suppress_detailed_output)
                    self.file_logger.log(f"       →  {mod_line.strip()}", to_console=not self.suppress_detailed_output)
                else:
                    # Normal console output when no output file
                    logger.info(f"  Line {i+1}: {orig_line.strip()}")
                    logger.info(f"       →  {mod_line.strip()}")

    def get_stats(self) -> Dict[str, int]:
        """Get migration statistics"""
        return self.stats.copy()
